class Building:
    def __init__(self, func, cost, level_requirement):
        self.cost = cost
        self.level_requirement = level_requirement