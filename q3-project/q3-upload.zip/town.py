class Town:
    def __init__(self, name, population, level, buildings, storage = {"wood": 0, "stone": 0, "food": 0}):
        self.name = name
        self.population = population
        self.level = level
        self.buildings = buildings
        self.storage = storage

    def manage_people(population):
        pass # hand out tasks

